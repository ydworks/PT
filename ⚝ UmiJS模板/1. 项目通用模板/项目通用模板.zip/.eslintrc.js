module.exports = {
  extends: [require.resolve('@umijs/fabric/dist/eslint')],
};
