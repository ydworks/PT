const Layouts = ({ children }) => {
  return <>{children}</>
}

export default Layouts
