// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'C:/Users/tangbohu/Desktop/GitLab/vcsynweb/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/login",
    "component": require('C:/Users/tangbohu/Desktop/GitLab/vcsynweb/src/pages/login').default,
    "exact": true
  },
  {
    "path": "/",
    "component": require('@/layouts').default,
    "routes": [
      {
        "path": "/",
        "redirect": "/home",
        "exact": true
      },
      {
        "path": "/home",
        "component": require('C:/Users/tangbohu/Desktop/GitLab/vcsynweb/src/pages/home').default,
        "exact": true
      },
      {
        "component": require('@/pages/404').default,
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
