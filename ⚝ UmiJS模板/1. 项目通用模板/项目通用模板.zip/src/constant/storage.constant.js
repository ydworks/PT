/**
 * @desc: 存储key信息
 */

export const USER_KEY = 'user'; //用户数据
