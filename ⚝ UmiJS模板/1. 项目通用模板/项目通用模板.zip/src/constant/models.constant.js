/**
 * @desc: useModel模块名
 */

export const USER_MODEL = 'user';
