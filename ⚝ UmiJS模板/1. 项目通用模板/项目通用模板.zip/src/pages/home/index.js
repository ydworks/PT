import styles from './index.module.less';

export default function IndexPage() {
  return (
    <div>
      <h1 className={styles.title}>Home Page</h1>
    </div>
  );
}
