/* 404页面  */
const NotFoundPage = () => {
  return (
    <>
      <h1>访问出错，请联系管理员，或返回首页</h1>
      <a href="/">返回首页</a>
    </>
  );
};

export default NotFoundPage;
