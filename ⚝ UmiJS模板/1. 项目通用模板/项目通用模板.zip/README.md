# umi project

## Getting Started

Install dependencies,

```bash
$ yarn
```

Start the dev server,

```bash
$ yarn dev
```



## Rules of Use 

> 1. 使用 `UmiJS` 创建项目，将 `package.json` 替换进 `模板` (注：此模板无 `ts`)
> 2. 根据项目所需，安装 `package`
